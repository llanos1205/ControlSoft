db_name="testDB"
db_host="database-1.crjadh7u9upe.us-east-1.rds.amazonaws.com"
db_user="postgresadm"
db_password="altair1205"