db_name="testDB"
db_host="database-1.crjadh7u9upe.us-east-1.rds.amazonaws.com"
db_user="postgresadm"
db_password="altair1205"
#_psycopg.cpython-37m-x86_64-linux-gnu.so