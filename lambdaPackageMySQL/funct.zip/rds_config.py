#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "altair1205"
db_name = "testDB" 
db_host="database-2.crjadh7u9upe.us-east-1.rds.amazonaws.com"